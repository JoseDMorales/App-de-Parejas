import { createContext, useState, useContext, useEffect } from "react";
import { registerRequest, loginRequest } from '../api/auth';
import Cookies from 'js-cookie';

export const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [errors, setErrors] = useState([]);
  const [loading, setLoading] = useState(true);

  const signup = async (user) => {
    try {
      const res = await registerRequest(user);

      if (res && res.data) {
        setUser(res.data);
        setIsAuthenticated(true);
        Cookies.set("token", res.data.token, { expires: 7 });
      } else {
        console.error("La respuesta o la propiedad 'data' es undefined.");
      }
    } catch (error) {
      console.log(error.response);
      setErrors(error.response);
    }
  };

  const logout = () => {
    Cookies.remove("token");
    setIsAuthenticated(false);
    setUser(null);
  };

  const signin = async (user) => {
    try {
      const res = await loginRequest(user);

      if (res && res.data) {
        setIsAuthenticated(true);
        setUser(res.data);
        Cookies.set("token", res.data.token, { expires: 7 });
      } else {
        console.error("La respuesta o la propiedad 'data' es undefined.");
      }
    } catch (error) {
      console.log(error);
      if (Array.isArray(error.response)) {
        setErrors(error.response);
      } else {
        setErrors([error.response]);
      }
    }
  };

  useEffect(() => {
    async function checkLogin() {
      const storedToken = Cookies.get("token");

      if (!storedToken) {
        setIsAuthenticated(false);
        setLoading(false);
        return setUser(null);
      }
      setIsAuthenticated(true);
      setUser({ });
      setLoading(false);
    }

    checkLogin();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        signup,
        signin,
        logout,
        loading,
        user,
        isAuthenticated,
        errors,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};